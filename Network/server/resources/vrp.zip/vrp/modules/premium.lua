-----------------------------------------------------------------------------------------------------------------------------------------
-- SETPREMIUM
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.SetPremium(source)
    if Characters[source] then
        vRP.Query("accounts/setPremium",{ license = Characters[source]["license"], premium = os.time() + 2592000 })
        Characters[source]["premium"] = parseInt(os.time() + 2592000)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- UPGRADEPREMIUM
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.UpgradePremium(source)
    if Characters[source] then
        vRP.Query("accounts/updatePremium",{ license = Characters[source]["license"] })
        Characters[source]["premium"] = Characters[source]["premium"] + 2592000
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- USERPREMIUM
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.UserPremium(Passport)
    local Source =  vRP.Source(Passport)
    local HasPermission = vRP.HasPermission(Passport,"Premium")
    if Characters[Source] then
        if Characters[Source]["premium"] < os.time() then
            if HasPermission then
                vRP.RemovePermission(Passport,"Premium")
            end
            return false
        elseif not HasPermission then
            vRP.SetPermission(Passport,"Premium")
        end
        return true
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- LICENSEPREMIUM
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.LicensePremium(License)
    local Account = vRP.Account(License)
    if Account and Account["premium"] >= os.time() then
        return true
    end
    return false
end



-----------------------------------------------------------------------------------------------------------------------------------------
-- SETPREMIUM PRATA
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.SetPremiumPrata(source)
    if Characters[source] then
        vRP.Query("accounts/setPremium",{ license = Characters[source]["license"], premium = os.time() + 2592000 })
        Characters[source]["premiumprata"] = parseInt(os.time() + 2592000)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- UPGRADEPREMIUM
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.UpgradePremiumPrata(source)
    if Characters[source] then
        vRP.Query("accounts/updatePremiumprata",{ license = Characters[source]["license"] })
        Characters[source]["premiumprata"] = Characters[source]["premiumprata"] + 2592000
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- USERPREMIUM
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.UserPremiumPrata(Passport)
    local Source =  vRP.Source(Passport)
    local HasPermission = vRP.HasPermission(Passport,"PremiumPrata")
    if Characters[Source] then
        if Characters[Source]["premium"] < os.time() then
            if HasPermission then
                vRP.RemovePermission(Passport,"PremiumPrata")
            end
            return false
        elseif not HasPermission then
            vRP.SetPermission(Passport,"PremiumPrata",1)
        end
        return true
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- LICENSEPREMIUM
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.LicensePremiumPrata(License)
    local Account = vRP.Account(License)
    if Account and Account["premiumprata"] >= os.time() then
        return true
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- SETPREMIUM OURO
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.SetPremiumOuro(source)
    if Characters[source] then
        vRP.Query("accounts/setPremium",{ license = Characters[source]["license"], premium = os.time() + 2592000 })
        Characters[source]["premiumouro"] = parseInt(os.time() + 2592000)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- UPGRADEPREMIUM
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.UpgradePremiumOuro(source)
    if Characters[source] then
        vRP.Query("accounts/updatePremiumouro",{ license = Characters[source]["license"] })
        Characters[source]["premiumouro"] = Characters[source]["premiumouro"] + 2592000
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
---USERPREMIUM
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.UserPremiumOuro(Passport)
    local Source =  vRP.Source(Passport)
    local HasPermission = vRP.HasPermission(Passport,"PremiumOuro")
    if Characters[Source] then
        if Characters[Source]["premium"] < os.time() then
            if HasPermission then
                vRP.RemovePermission(Passport,"PremiumOuro")
            end
            return false
        elseif not HasPermission then
            vRP.SetPermission(Passport,"PremiumOuro",1)
        end
        return true
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- LICENSEPREMIUM
-----------------------------------------------------------------------------------------------------------------------------------------
function vRP.LicensePremiumOuro(License)
    local Account = vRP.Account(License)
    if Account and Account["premiumouro"] >= os.time() then
        return true
    end
    return false
end
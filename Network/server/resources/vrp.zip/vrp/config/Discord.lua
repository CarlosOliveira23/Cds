-----------------------------------------------------------------------------------------------------------------------------------------
-- DISCORDS
-----------------------------------------------------------------------------------------------------------------------------------------
Discords = {
	["Connect"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Disconnect"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Airport"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Deaths"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Police"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Paramedic"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Gemstone"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Login"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	-- Contraband
	["Chiliad"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Families"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Highways"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Vagos"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	-- Favelas
	["Barragem"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Farol"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Parque"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Sandy"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Petroleo"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Praia-1"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Praia-2"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Zancudo"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
    -- Mafias
	["Madrazzo"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Playboy"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["TheSouth"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Vineyard"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	-- LOGS ADMINS
	["Tpto"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Tptome"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Fix"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Blips"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["God"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Ban"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Unban"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Kick"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Item"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Itemall"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Item2"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Group"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Ungroup"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Garages"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Clearchest"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Clearinv"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["SetBank"] = "",
	["Addcar"] = "",
	["Remcar"] = "",
	["Addback"] = "",
	["Remback"] = "",
	["wl"] = "",
	["Remback"] = "",
	["Noclip"] = "",
	["Tuning"] = "",
	-- LOGS KADUZERA
	["Prisao"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Multas"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Deposito"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Saque"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Avisopm"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Avisomec"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["LojaPolicia"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["LojaVip"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["Helicrash"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["InventoryPegou"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["InventoryLixo"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["InventoryDrops"] = "https://discord.com/api/webhooks/1151825910782230588/LzbqufOkJa6_L95q8MrvUfj0l-BPOWkSEqYtDV1R23n4HAfiW9_oZMP5qjJJPFAiclBO",
	["InventoryEnviou"] = ""
}

-----------------------------------------------------------------------------------------------------------------------------------------
-- DISCORD
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Discord",function(Hook,Message,Color)
	PerformHttpRequest(Discords[Hook],function(err,text,headers) end,"POST",json.encode({
		username = ServerName,
		embeds = { { color = Color, description = Message } }
	}),{ ["Content-Type"] = "application/json" })
end)


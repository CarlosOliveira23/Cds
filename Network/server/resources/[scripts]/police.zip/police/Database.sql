CREATE TABLE IF NOT EXISTS `police_prison` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `police` varchar(255) DEFAULT '0',
    `nuser_id` int(11) NOT NULL DEFAULT '0',
    `services` int(11) NOT NULL DEFAULT '0',
    `fines` int(20) NOT NULL DEFAULT '0',
    `text` longtext,
    `date` text,
    `cops` longtext NOT NULL DEFAULT '0',
    `association` longtext NOT NULL DEFAULT '0',
    `residual` text,
    `url` longtext,
    PRIMARY KEY (`id`),
    KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `police_gunlicense` (
    `portId` int(11) NOT NULL AUTO_INCREMENT,
    `identity` longtext,
    `user_id` text,
    `portType` longtext,
    `serial` longtext,
    `nidentity` longtext,
    `weapon` longtext,
    `exam` longtext,
    `date` text,
    PRIMARY KEY (`portId`),
    KEY `portId` (`portId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `police_reports` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `victim_id` text,
    `police_name` text,
    `solved` text,
    `victim_name` text,
    `created_at` text,
    `victim_report` text,
    `updated_at` text,
    PRIMARY KEY (`id`),
    KEY `portId` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `police_warrants` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` text,
    `identity` text,
    `status` text,
    `nidentity` text,
    `timeStamp` text,
    `reason` text,
    PRIMARY KEY (`id`),
    KEY `portId` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;